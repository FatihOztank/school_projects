from Crypto.Hash import SHA3_256
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from multiprocessing import Process
import random
from flask import Flask, request
import requests
import json

URL = "http://127.0.0.1:5000"
app = Flask(__name__)
processList = []
maliciousList = []


maliciousMsg = ""
transCount = 6  # num of transactions in a block, should also change this while grading for various
# values of transact num in order to make tester work !!!!!


@app.route("/", methods=["GET","POST"])
def serverSide():

    while True:
        a = request.get_json()
        print(a)

        if a is not None:
            processList.append(a)

        return {"data":processList}


@app.route("/secretapi",methods=["GET","POST"])  # secret api
def secretSide():
    while True:
        a = request.get_json()
        print(a)

        if a is not None:
            maliciousList.append(a)

        return {"data":maliciousList,"msg":maliciousMsg}


if __name__ =="__main__":
    for x in range(transCount):
        maliciousMsg += "blahblahblahblah I am a malicious message\n"
    app.run(debug=True)

