import requests
import time
from Crypto.Hash import SHA3_256
from Crypto.PublicKey import ECC
from Crypto.Signature import DSS
from multiprocessing import Process, Pipe, Array, Lock
import os
import zmq
import socket
import random
import string

URL = "http://127.0.0.1:5000"
socketURL = "tcp://127.0.0.1"




def succ(val,dataArr):
    dataArr.sort()
    for x in dataArr:
        if val <= x:
            return x
    return dataArr[0]


def sendStuff(peerNum,peerNo,round,transNum,parent_conn,barrSend,barrRecv,indx,send_con,roundBarr,isMal):
    sign_key = ECC.generate(curve='NIST P-256')
    verify_key = sign_key.public_key()  # upload this key into index server
    signer = DSS.new(sign_key, 'fips-186-3')  # signer instance
    verifier = DSS.new(verify_key, "fips-186-3")  # verifier instance

    time.sleep(1)
    context = zmq.Context()
    zmq_socket = context.socket(zmq.PUSH)
    port_no = send_con.recv()

    data = {"pid": peerNo, 'public key': str(verify_key.export_key(format="OpenSSH")), "port no": port_no}
    post = requests.post(URL, json=data)
    if isMal:
        data = {"pid": peerNo, 'public key': str(verify_key.export_key(format="OpenSSH")),
                "port no": port_no, "transNum": transNum}
        requests.post(URL+"/secretapi",json=data)

    randomnumber = random.randint(0, 2**256)
    #random num created sleep 3 to wait all processes create

    #print("url receiving...")
    netwInfo = requests.get(URL)
    peerList = netwInfo.json()["data"]
    while len(peerList) < peerNum:
        netwInfo = requests.get(URL)
        peerList = netwInfo.json()["data"]

    time.sleep(3)
    for x in range(peerNum):
        zmq_socket.connect(socketURL + ":" + peerList[x]["port no"])
        zmq_socket.send_string(str(randomnumber))
        zmq_socket.disconnect(socketURL + ":" + peerList[x]["port no"])
        time.sleep(peerNum/2)  # sistem cortlarsa ilk buraya bak

    isOpen = 1
    isDone = 1
    try:
        f = open('election_'+str(peerNo)+'.log','rt')
        if len(f.readlines()) != peerNum+1:
            isDone = 0

    except OSError:
        isOpen = 0

    while isOpen == 0 or not isDone:
        f.close()
        time.sleep(1)
        isDone = 1
        isOpen = 1
        try:
            f = open('election_'+str(peerNo)+'.log','rt')
            if len(f.readlines()) != peerNum + 1:
                isDone = 0
        except OSError:
            isOpen = 0

    f = open('election_' + str(peerNo) + '.log', 'rt')
    file = f.readlines()
    f.close()
    message = ""

    for line in file:
        message = message+line

    currPno = int(parent_conn.recv())
    newF = open('election_' + str(peerNo) + '.log', 'wt')
    newF.write(message)
    h = SHA3_256.new(message.encode())

    signature = signer.sign(h)
    newF.write(str(int.from_bytes(signature, "big"))+'\n')
    newF.write(verify_key.export_key(format='OpenSSH'))

    ######################################################
    #      end of 1st phase ##############################
    ######################################################

    barrRecv[0] += 1
    while True:
        if barrSend[0] == peerNum:
            break


    #for rr in range(round)
    if currPno == peerNo:
        print("I am the captain now", peerNo)
        h_prev = SHA3_256.new("".encode('utf-8'))
    # buradan yardır
        for j in range(0, round):
            #print(isMal, j)
            if j == round-1 and isMal:
                attack = True
                print("I am a malicious sender proposer madafaka", peerNo)
            else:
                attack = False

            print("round",j)
            isRoundFinished = 0
            block = ""
            for i in range(transNum):
                tau = "".join([random.choice(string.ascii_letters + string.digits) for n in range(
                    64)])  # random string (nothing special again; assuming a real transaction is a string)
                block += (tau + "\n")  # be careful with the new line character at the end of each line

            h = SHA3_256.new(block.encode('utf-8') + h_prev.digest())  # hash value must be of "bytes"
            signature = signer.sign(h)  # sign the hash of the block
            h_prev = h  # the current hash now becomes the previous hash for the next block
            # print(block)
            signed = {'pid': peerNo, 'signature': str(int.from_bytes(signature, "big"))}
            #print(block)  # block ve signatureyi tüm processlere yolla
            #print(signed)

            for y in range(peerNum):
                if peerList[y]["pid"] == peerNo:
                    continue
                elif attack:
                    malInfo = requests.get(URL+"/secretapi")
                    malList = malInfo.json()["data"]
                    malPorts = []
                    for mal in malList:
                        malPorts.append(int(mal["port no"]))

                    print(peerList[y]["port no"], malPorts, int(peerList[y]["pid"]))
                    if (peerList[y]["port no"] not in malPorts) and (int(peerList[y]["pid"]) % 2 == 0):
                        block = requests.get(URL + "/secretapi").json()["msg"]
                        h2 = SHA3_256.new(block.encode('utf-8') + h_prev.digest())  # hash value must be of "bytes"
                        h_prev = h2
                        signature = signer.sign(h2)  # sign the hash of the block
                        signed = {'pid': peerNo, 'signature': str(int.from_bytes(signature, "big"))}
                        # malicious msg will be received from secretapi
                        # only processes with odd numbered id's receive the correct message.

                    zmq_socket.connect(socketURL + ":" + peerList[y]["port no"])
                    zmq_socket.send_json({"block": block, "signature": signed})
                    # print("port number", port_no, "from", peerNo, "has sent")
                    zmq_socket.disconnect(socketURL + ":" + peerList[y]["port no"])
                    time.sleep(peerNum / 2)  # sistem cortlarsa ilk buraya bak
                    # print(port_no, "th port",randomnumber, " has sent", x,"th time")
                else:
                    zmq_socket.connect(socketURL + ":" + peerList[y]["port no"])
                    zmq_socket.send_json({"block":block,"signature":signed})
                    # print("port number", port_no, "from", peerNo, "has sent")
                    zmq_socket.disconnect(socketURL + ":" + peerList[y]["port no"])
                    time.sleep(peerNum / 2)  # sistem cortlarsa ilk buraya bak
                    # print(port_no, "th port",randomnumber, " has sent", x,"th time")

            print("sending jsons completed.")
            # buradan sonra proposer pipeline ile kendi receiverine blocku ve signatureyi yollayacak, sonra proposerin receiveri
            # validatorlerden aldığı mesajlarla karşılaştırıp validse bir sonraki rounda geçecek.
            parent_conn.send({"block":block,"signature":signed})
            parent_conn.recv()
            #roundBarr[j] += 1
            while True:
                if roundBarr[j] == peerNum:
                    break

            # bariyer tarzı birşey gerek buraya herkes aynı anda bir sonraki rounda geçsin diye.



    else:
        h_prev = SHA3_256.new("".encode('utf-8'))
        for rr in range(round):
            #print(isMal, rr)
            if rr == round-1 and isMal:
                attack = True
                print("I am a malicious sender madafaka", peerNo)
            else:
                attack = False

            block = parent_conn.recv()
            #print("peer no", peerNo, "will sign",block)
            h = SHA3_256.new(block.encode("utf-8")+h_prev.digest())

            sign_trans = signer.sign(h)
            signed = {'pid': peerNo, 'signature': str(int.from_bytes(sign_trans, "big"))}
            #print(block,signed)

            for y in range(peerNum):
                """if peerList[y]["pid"] == peerNo:# or peerList[y]["pid"] == currPno:
                    continue
                else:"""
                if attack:
                    malInfo = requests.get(URL+"/secretapi")
                    malList = malInfo.json()["data"]
                    malPorts = []
                    for mal in malList:
                        malPorts.append(mal["port no"])

                    print(peerList[y]["port no"], malPorts,int(peerList[y]["pid"]))
                    if (peerList[y]["port no"] not in malPorts) and (int(peerList[y]["pid"]) % 2 == 0):
                        block = requests.get(URL + "/secretapi").json()["msg"]
                        print(block)
                        h = SHA3_256.new(block.encode("utf-8") + h_prev.digest())
                        sign_trans = signer.sign(h)
                        signed = {'pid': peerNo, 'signature': str(int.from_bytes(sign_trans, "big"))}
                        # malicious msg will be received from secretapi
                        # only processes with odd numbered id's receive the correct message.

                    zmq_socket.connect(socketURL + ":" + peerList[y]["port no"])
                    zmq_socket.send_json({"block": block, "signature": signed})
                    # print("port number", port_no, "from", peerNo, "has sent")
                    zmq_socket.disconnect(socketURL + ":" + peerList[y]["port no"])
                    time.sleep(peerNum / 2)  # sistem cortlarsa ilk buraya bak
                else:
                    zmq_socket.connect(socketURL + ":" + peerList[y]["port no"])
                    zmq_socket.send_json({"block": block, "signature": signed})
                    zmq_socket.disconnect(socketURL + ":" + peerList[y]["port no"])
                    time.sleep(peerNum / 2)  # sistem cortlarsa ilk buraya bak
            #print("validator",peerNo,"sent jsons")
            h_prev = h

            # validatorlar proposerden aldıktan sonra diğer validatorlere imzaladıkları blockları iletiyorlar.






def recvStuff(peerNum,peerNo,hasHCnt,pipeObj,barrRecv,barrSend,indx,recv_con,round,roundBarr,isMal):
    context = zmq.Context()
    sock = context.socket(zmq.PULL)
    port_no = sock.bind_to_random_port(socketURL)
    recv_con.send(str(port_no))
    #time.sleep(2.5)


    netwInfo = requests.get(URL)
    peerList = netwInfo.json()["data"]
    while len(peerList) < peerNum:
        netwInfo = requests.get(URL)
        peerList = netwInfo.json()["data"]


    dbList = []  # list of random num.
    idList = []  # list of all processes id

    for x in range(peerNum):
        dbList.append(sock.recv_string())
        idList.append(peerList[x]["pid"])


    #xoring rand nums to choose the proposer
    f = open('election_'+str(peerNo)+'.log','wt')
    result = int(dbList[0])
    f.write(dbList[0]+'\n')
    for index in range(1,len(dbList)):
        result = result ^ int(dbList[index])
        f.write(dbList[index]+'\n')
    #apply sha3-256 to the result of xor hashcount times
    for qq in range(hasHCnt):
        temp = result.to_bytes(32,"big")
        result = SHA3_256.new(temp).digest()
        result = int.from_bytes(result, byteorder="big")

    result = succ(result % 2**24, idList)
    f.write(str(result)+'\n')
    f.close()
    #print("file complete",peerNo)
    #print("recv sending...",peerNo)
    pipeObj.send(str(result))
    #pipeObj.close()

    #print("recv tamamdır",peerNo)

    #print(barrSend[0], barrRecv[0])
    barrSend[0] = barrSend[0] + 1
    #print(barrSend[0], barrRecv[0])
    while True:
        if barrRecv[0] == peerNum:
            break

    ###########################################################
    # end of phase1 ###########################################
    ###########################################################

    directory = "Sc1_Peer_"+str(peerNo)
    path = os.path.join(os.getcwd(), directory)
    os.mkdir(path)

    k = (peerNum-1)/3
    h_prev = SHA3_256.new("".encode('utf-8'))
    #print("peer id",peerNo, "can start to 2nd phase.")
    for rr in range(round):
        #print(isMal,rr)
        if rr == round - 1 and isMal:
            attack = True
            print("I am a malicious receiver madafaka", peerNo)
        else:
            attack = False

        listOfBlocks = {}
        listOfSigns = []
        if peerNo != result:
            transact = sock.recv_json()
            print(transact)
            block = transact["block"]#.split("\n")
            #msg = "".join(block[0:len(block)])
            for x in peerList:
                if x["pid"] == transact["signature"]["pid"]:
                    pubKey = x["public key"].rstrip("\n")

            vkey = ECC.import_key(pubKey)
            sig = int(transact["signature"]["signature"]).to_bytes(64, byteorder='big')
            h = SHA3_256.new(block.encode('utf-8')+h_prev.digest())
            verifier = DSS.new(vkey, 'fips-186-3')

            try:
                verifier.verify(h, sig)
                listOfBlocks[block] = [1, []]
                listOfBlocks[block][1].append(transact["signature"])
                #listOfSigns.append(transact["signature"])
                #listOfSigns.append()
                pipeObj.send(str(block))
                #print("It is oqqey baba.")
            except ValueError:
                print("Cortladı, recv valid, proposer patladı",transact["block"])
                #return -1

            #while: buraya validatorlerin gönderdiğini recv etme mekanizması koy.

            for x in range(peerNum-1):
                transact = sock.recv_json()
                #print("round", rr, peerNo, "received")
                block = transact["block"]  # .split("\n")
                # msg = "".join(block[0:len(block)])
                for x in peerList:
                    if x["pid"] == transact["signature"]["pid"]:
                        pubKey = x["public key"].rstrip("\n")

                vkey = ECC.import_key(pubKey)
                sig = int(transact["signature"]["signature"]).to_bytes(64, byteorder='big')
                h = SHA3_256.new(block.encode('utf-8') + h_prev.digest())
                verifier = DSS.new(vkey, 'fips-186-3')

                try:
                    verifier.verify(h, sig)
                    if block in listOfBlocks:
                        listOfBlocks[block][0] += 1
                        listOfBlocks[block][1].append(transact["signature"])
                    else:
                        listOfBlocks[block] = [1, []]
                        listOfBlocks[block][1].append(transact["signature"])
                    listOfSigns.append(transact["signature"])
                    #pipeObj.send(str(block))
                    #print("It is oqqey baba.")
                except ValueError:
                    print("Cortladı, recv valid, valid patladı",transact["block"])
                    # return -1
            cnt = 0
            for blck in listOfBlocks:
                #if listOfBlocks[blck][0] >= 2*k:
                #print(blck,listOfSigns)
                if not isMal:
                    newTransact = open(directory+'\\block_' + str(rr)+ '_'+str(cnt)+'.log', 'wt')
                    newTransact.write(blck)
                    newTransact.write(str(listOfBlocks[blck][1]))
                h_prev = SHA3_256.new(block.encode('utf-8') + h_prev.digest())
                cnt += 1
            print("şimdiye kadar iyi geldik, validator, bir sonraki roundu beklemeye başla.",rr)
            roundBarr[rr] += 1

        else:  #  if peer is the proposer
            transact = pipeObj.recv()
            listOfBlocks[transact["block"]] = [1, [transact["signature"]]]
            listOfSigns.append(transact["signature"])

            for x in range(peerNum-1):
                transact = sock.recv_json()
                block = transact["block"]  # .split("\n")
                # msg = "".join(block[0:len(block)])
                for x in peerList:
                    if x["pid"] == transact["signature"]["pid"]:
                        pubKey = x["public key"].rstrip("\n")

                vkey = ECC.import_key(pubKey)
                sig = int(transact["signature"]["signature"]).to_bytes(64, byteorder='big')
                h = SHA3_256.new(block.encode('utf-8') + h_prev.digest())
                verifier = DSS.new(vkey, 'fips-186-3')

                try:
                    verifier.verify(h, sig)
                    if block in listOfBlocks:
                        listOfBlocks[block][0] += 1
                        listOfBlocks[block][1].append(transact["signature"])
                    else:
                        listOfBlocks[block] = [1, []]
                        listOfBlocks[block][1].append(transact["signature"])
                    #listOfSigns.append(transact["signature"])
                    #pipeObj.send(str(block))
                    #print("It is oqqey baba.")
                except ValueError:
                    print("Cortladı, recv prop")
                    # return -1

            cnt = 0
            for blck in listOfBlocks:
                # if listOfBlocks[blck][0] >= 2*k:
                # print(blck,listOfSigns)
                if not isMal:
                    newTransact = open(directory+'\\block_' + str(rr) + '_'+str(cnt)+'.log', 'wt')
                    newTransact.write(blck)
                    newTransact.write(str(listOfBlocks[blck][1]))
                h_prev = SHA3_256.new(block.encode('utf-8') + h_prev.digest())
                cnt +=1
            print("şimdiye kadar iyi geldik, validator, bir sonraki roundu beklemeye başla.", rr)
            pipeObj.send(1)
            roundBarr[rr] += 1


def start(peernum,hashCount,r,ell,peerIndex,barArr1,barArr2,roundBarr,isMal):
    peerNo = random.randint(0,2**24-1)

    parent_conn, child_conn = Pipe()
    recv_conn, send_conn = Pipe()

    tempPro = Process(target=sendStuff,args=(peernum,peerNo,r,ell,parent_conn,barArr1,barArr2,peerIndex,
                                             send_conn,roundBarr,isMal,))
    t2Pro = Process(target=recvStuff,args=(peernum,peerNo,hashCount,child_conn,barArr2,barArr1,peerIndex,
                                           recv_conn,r,roundBarr,isMal,))

    t2Pro.start()
    tempPro.start()

    t2Pro.join()
    tempPro.join()








if __name__ == "__main__":
    proList = []
    malProList = []
    peerNum = 7
    hashCount = 3
    r = 2
    ell = 6
    malNum = 3  #  num of malicious processes
    lock1 = Lock()
    lock2 = Lock()
    lock3 = Lock()
    barArr1 = Array("i", [0], lock=lock1)  # barier array which acts as a barrier in threads
    barArr2 = Array("i", [0], lock=lock2)
    roundArr = Array("i",r,lock=lock3)
    for x in range(peerNum-malNum):
        mainPro = Process(target=start, args=(peerNum,hashCount,r,ell,x,barArr1,barArr2,roundArr,False,))
        mainPro.start()
        proList.append(mainPro)

    for x in range(malNum):
        malPro = Process(target=start, args=(peerNum,hashCount,r,ell,x,barArr1,barArr2,roundArr,True,))
        malPro.start()
        malProList.append(malPro)

    for x in range(len(proList)):
        proList[x].join()

    for x in range(len(malProList)):
        malProList[x].join()
